package com.example.trumpdumpapi

import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response

class ApiCall {

    fun getQuotes(query: String): QuoteResponse?
    {
        val url = "https://www.tronalddump.io/search/quote?query=$query" ///URL
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(url)
            .build()

        val response: Response = client.newCall(request).execute()

        if (response.isSuccessful)
        {
            val jsonResponse = response.body?.string()
            return Gson().fromJson(jsonResponse, QuoteResponse::class.java)
        } else
        {
            return null
        }
    }
}