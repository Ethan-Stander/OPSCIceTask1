package com.example.trumpdumpapi

data class QuoteResponse(
    val count: Int,
    val total: Int,
    val _embedded: EmbeddedQuotes,
    val _links: Links
)

data class EmbeddedQuotes(
    val quotes: List<Quote>
)

data class Quote(
    val appeared_at: String,
    val created_at: String,
    val quote_id: String,
    val tags: List<String>,
    val updated_at: String,
    val value: String,
    val _embedded: EmbeddedDetails,
    val _links: QuoteLinks
)

data class EmbeddedDetails(
    val author: List<Author>,
    val source: List<Source>
)

data class Author(
    val author_id: String,
    val bio: String?,
    val created_at: String,
    val name: String,
    val slug: String,
    val updated_at: String,
    val _links: AuthorLinks
)

data class AuthorLinks(
    val self: Link
)

data class Source(
    val created_at: String,
    val filename: String?,
    val quote_source_id: String,
    val remarks: String?,
    val updated_at: String,
    val url: String,
    val _links: SourceLinks
)

data class SourceLinks(
    val self: Link
)

data class QuoteLinks(
    val self: Link
)

data class Links(
    val self: Link,
    val first: Link,
    val prev: Link,
    val next: Link,
    val last: Link
)

data class Link(
    val href: String
)
